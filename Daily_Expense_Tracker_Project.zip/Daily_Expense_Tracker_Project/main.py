from __future__ import annotations
import csv
import json
import re
from collections import defaultdict
from datetime import datetime, date
from decimal import Decimal, InvalidOperation
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
REPORT_DIR = ROOT / "reports"
CHART_DIR = ROOT / "charts"
JSON_FILE = DATA_DIR / "expenses.json"
CSV_FILE = DATA_DIR / "expenses.csv"
CATEGORIES = ["Food", "Transport", "Education", "Shopping", "Bills", "Health", "Entertainment", "Other"]
FIELDS = ["id", "date", "category", "description", "amount", "payment_method"]

def ensure_dirs():
    for folder in (DATA_DIR, REPORT_DIR, CHART_DIR):
        folder.mkdir(parents=True, exist_ok=True)

def valid_date(value: str) -> str:
    try:
        parsed = datetime.strptime(value.strip(), "%Y-%m-%d").date()
        if parsed > date.today():
            raise ValueError("Date cannot be in the future.")
        return parsed.isoformat()
    except ValueError as exc:
        if "future" in str(exc):
            raise
        raise ValueError("Enter date in YYYY-MM-DD format (for example 2026-11-26).")

def valid_amount(value: str) -> str:
    try:
        amount = Decimal(value.strip())
        if not amount.is_finite() or amount <= 0 or amount > Decimal("100000000"):
            raise ValueError
        return f"{amount:.2f}"
    except (InvalidOperation, ValueError):
        raise ValueError("Amount must be a positive number up to 100,000,000.")

def clean_text(value: str, label: str, max_len: int) -> str:
    value = value.strip()
    if not value:
        raise ValueError(f"{label} cannot be blank.")
    if len(value) > max_len:
        raise ValueError(f"{label} must be {max_len} characters or fewer.")
    if any(ord(ch) < 32 for ch in value):
        raise ValueError(f"{label} contains unsupported control characters.")
    return value

def load_expenses():
    ensure_dirs()
    if JSON_FILE.exists():
        try:
            raw = json.loads(JSON_FILE.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("JSON root must be a list")
            records = []
            for item in raw:
                if not isinstance(item, dict):
                    continue
                try:
                    records.append(validate_record(item))
                except (ValueError, KeyError, TypeError):
                    continue
            return records
        except (json.JSONDecodeError, OSError, ValueError):
            backup = JSON_FILE.with_suffix(".corrupt.json")
            try:
                JSON_FILE.replace(backup)
                print(f"\n[Warning] Damaged JSON moved to {backup.name}. Starting with an empty dataset.")
            except OSError:
                print("\n[Warning] Could not read JSON storage. Starting with an empty dataset.")
    if CSV_FILE.exists():
        try:
            with CSV_FILE.open(newline="", encoding="utf-8") as handle:
                return [validate_record(row) for row in csv.DictReader(handle) if row]
        except (OSError, csv.Error, ValueError):
            print("[Warning] CSV storage could not be read. Starting with an empty dataset.")
    return []

def validate_record(item):
    record = {
        "id": clean_text(str(item["id"]), "ID", 40),
        "date": valid_date(str(item["date"])),
        "category": clean_text(str(item["category"]), "Category", 30),
        "description": clean_text(str(item["description"]), "Description", 100),
        "amount": valid_amount(str(item["amount"])),
        "payment_method": clean_text(str(item.get("payment_method", "Not specified")), "Payment method", 30)
    }
    if record["category"] not in CATEGORIES:
        record["category"] = "Other"
    return record

def save_expenses(expenses):
    ensure_dirs()
    JSON_FILE.write_text(json.dumps(expenses, indent=2, ensure_ascii=False), encoding="utf-8")
    with CSV_FILE.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(expenses)

def prompt_value(label, validator, default=None):
    while True:
        raw = input(f"{label}" + (f" [{default}]" if default is not None else "") + ": ").strip()
        if not raw and default is not None:
            raw = str(default)
        try:
            return validator(raw)
        except ValueError as exc:
            print(f"  ! {exc}")

def choose_category(default=None):
    print("Categories: " + " | ".join(f"{i+1}.{c}" for i, c in enumerate(CATEGORIES)))
    while True:
        raw = input(f"Choose category (1-{len(CATEGORIES)})" + (f" [{CATEGORIES.index(default)+1}]" if default in CATEGORIES else "") + ": ").strip()
        if not raw and default in CATEGORIES:
            return default
        if raw.isdigit() and 1 <= int(raw) <= len(CATEGORIES):
            return CATEGORIES[int(raw)-1]
        if raw.title() in CATEGORIES:
            return raw.title()
        print("  ! Choose a listed number or category name.")

def add_expense(expenses):
    print("\n--- Add Expense ---")
    today = date.today().isoformat()
    new_record = {
        "id": datetime.now().strftime("%Y%m%d%H%M%S%f"),
        "date": prompt_value("Date (YYYY-MM-DD)", valid_date, today),
        "category": choose_category(),
        "description": prompt_value("Description", lambda x: clean_text(x, "Description", 100)),
        "amount": prompt_value("Amount (INR)", valid_amount),
        "payment_method": prompt_value("Payment method", lambda x: clean_text(x, "Payment method", 30), "Cash")
    }
    expenses.append(new_record)
    save_expenses(expenses)
    print("✓ Expense saved successfully.")

def money(value):
    return f"₹{Decimal(str(value)):,.2f}"

def show_table(records):
    if not records:
        print("\nNo expenses found.")
        return
    print("\n" + "-" * 105)
    print(f"{'No.':<4} {'Date':<12} {'Category':<16} {'Description':<28} {'Amount':>13} {'Payment':<15}")
    print("-" * 105)
    for i, item in enumerate(sorted(records, key=lambda x: (x["date"], x["id"]), reverse=True), 1):
        desc = item["description"][:26] + (".." if len(item["description"]) > 26 else "")
        print(f"{i:<4} {item['date']:<12} {item['category']:<16} {desc:<28} {money(item['amount']):>13} {item['payment_method'][:15]:<15}")
    print("-" * 105)
    print(f"Records: {len(records)} | Total: {money(sum(Decimal(x['amount']) for x in records))}")

def view_expenses(expenses):
    print("\n--- All Expenses ---")
    show_table(expenses)

def search_expenses(expenses):
    term = input("\nEnter keyword (description/category/payment): ").strip().lower()
    if not term:
        print("Search text cannot be blank.")
        return
    matches = [x for x in expenses if term in " ".join([x["description"], x["category"], x["payment_method"]]).lower()]
    show_table(matches)

def filter_category(expenses):
    category = choose_category()
    show_table([x for x in expenses if x["category"] == category])

def monthly_summary(expenses):
    month = prompt_value("Month (YYYY-MM)", lambda x: x if re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", x) else (_ for _ in ()).throw(ValueError("Use YYYY-MM format.")), date.today().strftime("%Y-%m"))
    selected = [x for x in expenses if x["date"].startswith(month)]
    print(f"\n--- Monthly Summary: {month} ---")
    if not selected:
        print("No expenses recorded for this month.")
        return
    total = sum(Decimal(x["amount"]) for x in selected)
    by_category = defaultdict(Decimal)
    for item in selected:
        by_category[item["category"]] += Decimal(item["amount"])
    print(f"Transactions : {len(selected)}")
    print(f"Total spent  : {money(total)}")
    print(f"Daily average: {money(total / Decimal(str(max(1, int(month.split('-')[1]) if month == date.today().strftime('%Y-%m') else 30))))}")
    print("\nCategory breakdown")
    for category, amount in sorted(by_category.items(), key=lambda p: p[1], reverse=True):
        percent = amount / total * 100 if total else 0
        print(f"  {category:<18} {money(amount):>15}  ({percent:.1f}%)")
    if len(by_category) > 0:
        top = max(by_category, key=by_category.get)
        print(f"\nHighest spending category: {top}")

def delete_expense(expenses):
    show_table(expenses)
    if not expenses:
        return
    raw = input("Enter record number to delete (or 0 to cancel): ").strip()
    if not raw.isdigit() or int(raw) < 0 or int(raw) > len(expenses):
        print("Invalid record number.")
        return
    if int(raw) == 0:
        return
    ordered = sorted(expenses, key=lambda x: (x["date"], x["id"]), reverse=True)
    target = ordered[int(raw)-1]
    confirm = input(f"Delete {target['description']} ({money(target['amount'])})? (y/N): ").strip().lower()
    if confirm == "y":
        expenses.remove(target)
        save_expenses(expenses)
        print("✓ Record deleted.")
    else:
        print("Cancelled.")

def edit_expense(expenses):
    show_table(expenses)
    if not expenses:
        return
    raw = input("Enter record number to edit (or 0 to cancel): ").strip()
    if not raw.isdigit() or int(raw) < 0 or int(raw) > len(expenses):
        print("Invalid record number.")
        return
    if int(raw) == 0:
        return
    ordered = sorted(expenses, key=lambda x: (x["date"], x["id"]), reverse=True)
    item = ordered[int(raw)-1]
    print("Press Enter to keep the current value.")
    item["date"] = prompt_value("Date", valid_date, item["date"])
    item["category"] = choose_category(item["category"])
    item["description"] = prompt_value("Description", lambda x: clean_text(x, "Description", 100), item["description"])
    item["amount"] = prompt_value("Amount", valid_amount, item["amount"])
    item["payment_method"] = prompt_value("Payment method", lambda x: clean_text(x, "Payment method", 30), item["payment_method"])
    save_expenses(expenses)
    print("✓ Record updated.")

def export_reports(expenses):
    ensure_dirs()
    if not expenses:
        print("No records available to export.")
        return
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = REPORT_DIR / f"expense_report_{stamp}.csv"
    md_path = REPORT_DIR / f"expense_report_{stamp}.md"
    txt_path = REPORT_DIR / f"expense_audit_{stamp}.txt"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(expenses)
    total = sum(Decimal(x["amount"]) for x in expenses)
    lines = ["# Daily Expense Tracker Report", "", f"- Generated: {datetime.now():%Y-%m-%d %H:%M}", f"- Records: {len(expenses)}", f"- Total spending: {money(total)}", "", "| Date | Category | Description | Amount | Payment |", "|---|---|---|---:|---|"]
    for x in sorted(expenses, key=lambda r: r["date"]):
        lines.append(f"| {x['date']} | {x['category']} | {x['description'].replace('|', '/')} | {money(x['amount'])} | {x['payment_method']} |")
    md_path.write_text("\n".join(lines), encoding="utf-8")
    txt_path.write_text("\n".join([f"DAILY EXPENSE TRACKER AUDIT - {datetime.now():%Y-%m-%d %H:%M}", f"Records: {len(expenses)}", f"Total: {money(total)}", "-"*55] + [f"{x['date']} | {x['category']} | {x['description']} | {money(x['amount'])}" for x in expenses]), encoding="utf-8")
    print("✓ Reports exported:")
    for path in (csv_path, md_path, txt_path):
        print(f"  {path.relative_to(ROOT)}")

def generate_charts(expenses):
    if not expenses:
        print("No records available for charts.")
        return
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Matplotlib is not installed. Run: pip install -r requirements.txt")
        return
    ensure_dirs()
    by_category = defaultdict(float)
    by_month = defaultdict(float)
    for x in expenses:
        by_category[x["category"]] += float(x["amount"])
        by_month[x["date"][:7]] += float(x["amount"])
    fig, ax = plt.subplots(figsize=(9, 5))
    cats = sorted(by_category, key=by_category.get, reverse=True)
    ax.bar(cats, [by_category[c] for c in cats])
    ax.set_title("Expenses by Category")
    ax.set_ylabel("Amount (INR)")
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    p1 = CHART_DIR / "category_distribution.png"
    fig.savefig(p1, dpi=160)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(9, 5))
    months = sorted(by_month)
    ax.plot(months, [by_month[m] for m in months], marker="o")
    ax.set_title("Monthly Spending Trend")
    ax.set_ylabel("Amount (INR)")
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    p2 = CHART_DIR / "monthly_trend.png"
    fig.savefig(p2, dpi=160)
    plt.close(fig)
    print(f"✓ Charts saved: {p1.relative_to(ROOT)}, {p2.relative_to(ROOT)}")

def import_csv(expenses):
    path_text = input("CSV file path to import: ").strip().strip('"')
    path = Path(path_text).expanduser()
    if not path.is_file():
        print("File not found.")
        return
    added, errors = [], []
    try:
        with path.open(newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            required = set(FIELDS)
            if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
                print("CSV must contain columns: " + ", ".join(FIELDS))
                return
            for line_no, row in enumerate(reader, 2):
                try:
                    record = validate_record(row)
                    record["id"] = datetime.now().strftime("%Y%m%d%H%M%S%f") + str(line_no)
                    added.append(record)
                except (ValueError, KeyError, TypeError) as exc:
                    errors.append(f"Row {line_no}: {exc}")
    except (OSError, csv.Error) as exc:
        print(f"Could not import CSV: {exc}")
        return
    existing_ids = {x["id"] for x in expenses}
    added = [x for x in added if x["id"] not in existing_ids]
    expenses.extend(added)
    save_expenses(expenses)
    print(f"Imported {len(added)} valid rows; rejected {len(errors)} rows.")
    if errors:
        log = REPORT_DIR / "import_errors.txt"
        log.write_text("\n".join(errors), encoding="utf-8")
        print(f"Row error details: {log.relative_to(ROOT)}")

def print_menu():
    print("""
╔══════════════════════════════════════════════════════╗
║              DAILY EXPENSE TRACKER                  ║
║             Simple • Secure • Local                 ║
╠══════════════════════════════════════════════════════╣
║  1. Add expense              2. View all expenses   ║
║  3. Search expenses          4. Filter by category  ║
║  5. Monthly summary          6. Edit an expense     ║
║  7. Delete an expense        8. Export reports      ║
║  9. Generate charts         10. Import CSV          ║
║  0. Exit                                             ║
╚══════════════════════════════════════════════════════╝
""")

def main():
    expenses = load_expenses()
    print("\nWelcome! Your expense records are stored locally on this device.")
    while True:
        print_menu()
        choice = input("Select an option: ").strip()
        actions = {
            "1": lambda: add_expense(expenses),
            "2": lambda: view_expenses(expenses),
            "3": lambda: search_expenses(expenses),
            "4": lambda: filter_category(expenses),
            "5": lambda: monthly_summary(expenses),
            "6": lambda: edit_expense(expenses),
            "7": lambda: delete_expense(expenses),
            "8": lambda: export_reports(expenses),
            "9": lambda: generate_charts(expenses),
            "10": lambda: import_csv(expenses)
        }
        if choice == "0":
            save_expenses(expenses)
            print("Your data has been saved. Goodbye!")
            break
        action = actions.get(choice)
        if action:
            try:
                action()
            except (KeyboardInterrupt, EOFError):
                print("\nAction cancelled.")
        else:
            print("Please select a valid menu option.")

if __name__ == "__main__":
    main()
