# Project Details

**Project:** Daily Expense Tracker  
**Domain:** Finance & Personal Management  
**Language:** Python 3.10+  
**Storage:** JSON and CSV  
**Visualization:** Matplotlib

## Module overview
- `main.py`: terminal interface, validation, expense operations, summaries, import/export and charts.
- `data/expenses.json`: sample records and primary local persistence file.
- `data/expenses.csv`: matching CSV dataset and persistence copy.
- `reports/`: generated export files and import validation logs.
- `charts/`: generated visual reports.

## Validation rules
- Date must be a real calendar date in `YYYY-MM-DD` format and cannot be in the future.
- Amount must be numeric, finite, greater than zero and no more than ₹10 crore.
- Description, category and payment method cannot be blank and have length limits.
- CSV import checks required columns and validates each row independently.

## Known behavior
If JSON is malformed, the application attempts to move it to a `.corrupt.json` backup and starts with an empty dataset (or reads CSV as fallback where possible). Matplotlib is optional; other features remain available without it.
