# Daily Expense Tracker

A beginner-friendly, menu-driven Python application built for CampusSolve Project #11.

## Features
- Add, view, edit and delete daily expense records
- Input validation for dates, amounts and text fields
- Categories, keyword search and category filtering
- Monthly totals, category breakdown and spending averages
- Automatic local JSON and CSV persistence
- CSV bulk import with row-by-row error logging
- Export CSV, Markdown and plain-text audit reports
- Matplotlib category and monthly trend charts
- 40 realistic sample records included

## Requirements
- Python 3.10 or newer
- Matplotlib (optional; needed only for charts)

## Run the project
1. Extract the ZIP file.
2. Open a terminal in the `daily_expense_tracker_project` folder.
3. (Recommended) Create and activate a virtual environment:

   **Windows**
   ```bash
   py -m venv .venv
   .venv\\Scripts\\activate
   ```

   **macOS / Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

4. Install chart dependency:
   ```bash
   pip install -r requirements.txt
   ```
5. Start the application:
   ```bash
   python main.py
   ```

## Data and generated files
- `data/expenses.json` and `data/expenses.csv`: sample and saved records
- `reports/`: exported reports and CSV import error logs
- `charts/`: generated PNG charts

The program writes to both JSON and CSV whenever records are changed. Keep a backup of the `data` folder if you need to preserve your records.

## Demo flow for presentation
1. Run `python main.py`.
2. Choose **1** and add an expense. Try entering an invalid amount first to demonstrate validation.
3. Choose **2** to show all records.
4. Choose **5** to show a monthly summary.
5. Choose **9** to create charts.
6. Choose **8** to export the reports.
7. Exit and relaunch the program to demonstrate that records persist.

## Notes
- All amounts are displayed in Indian Rupees (INR).
- Dates must use `YYYY-MM-DD`; future dates are rejected.
- The application is local-first and does not require an internet connection.
